package com.sultanburger.dialog.handler;

import com.sultanburger.data.item.ListDataItem;

public interface ListListener {

    void onSelected(ListDataItem listDataItem);
}
