package com.sultanburger.utils;

public interface DataReceiver<T> {
    void receiveData(T result);
}
