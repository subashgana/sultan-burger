package com.sultanburger.fragment.handler;

import com.sultanburger.data.output.BranchOutput;

public interface BranchHandler {

    void onBranchSelected(BranchOutput branchOutput);
}
