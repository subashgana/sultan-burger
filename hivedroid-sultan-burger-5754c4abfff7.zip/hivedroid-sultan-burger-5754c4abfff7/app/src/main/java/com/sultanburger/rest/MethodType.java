package com.sultanburger.rest;

public enum MethodType {
    POST,
    PUT,
    GET,
    DELETE
}
