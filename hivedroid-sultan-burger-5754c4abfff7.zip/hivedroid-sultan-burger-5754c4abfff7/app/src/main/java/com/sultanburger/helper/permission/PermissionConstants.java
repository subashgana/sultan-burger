package com.sultanburger.helper.permission;

public interface PermissionConstants {

    String SOME_PERMISSION_DENIED = "Some permissions are denied, Go to app settings and enable it";
    int REQUEST_ID_PERMISSION_MULTIPLE = 100;
}
