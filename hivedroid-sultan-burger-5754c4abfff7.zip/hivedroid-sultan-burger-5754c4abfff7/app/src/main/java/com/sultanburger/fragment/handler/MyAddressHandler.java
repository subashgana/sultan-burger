package com.sultanburger.fragment.handler;

import com.sultanburger.data.output.ListUserAddress;

public interface MyAddressHandler {

    void onAddressSelected(ListUserAddress listUserAddress);
}
