package com.sultanburger.fragment.handler;

import com.sultanburger.data.output.MyOrders;

public interface OrderTrackingHandler {

    void onOrderSelected(MyOrders myOrders);
}
