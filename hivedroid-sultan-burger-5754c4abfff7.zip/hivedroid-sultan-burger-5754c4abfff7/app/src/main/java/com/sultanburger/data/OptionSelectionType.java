package com.sultanburger.data;

public enum OptionSelectionType {

    PICKUP,
    DELIVERY,
    RE_ORDER
}
