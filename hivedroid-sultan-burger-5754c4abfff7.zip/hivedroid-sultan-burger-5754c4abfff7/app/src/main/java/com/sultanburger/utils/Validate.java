package com.sultanburger.utils;

import android.content.Context;

import com.sultanburger.AppConstants;

public interface Validate extends AppConstants {

    boolean isValid(Context context);
}
